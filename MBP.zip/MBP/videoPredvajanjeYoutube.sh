

ffmpeg \
panic -y -i "rtsp://192.168.1.188:554/user=admin&password=&channel=1&stream=0.sdp" \
-rtsp_transport tcp -vf \
drawtext="fontfile=arial.ttf:textfile=/home/peter/MBP/ffmpeg.txt:x=5:y=60:fontcolor=white:fontsize=25:reload=1:box=1:boxborderw=2:boxcolor=black@0.8" \
-threads 0 \
-vcodec libx264 -pix_fmt yuv420p -g 20 -b:v 1000k\ 
-preset veryfast \
-b:v 1000k -f flv "rtmp://a.rtmp.youtube.com/live2/h4dh-dbhb-efmv-dbx0"
